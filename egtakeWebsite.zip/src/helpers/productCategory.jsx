const productCategory = [
    {id : 1, label : 'Women', value : 'Women'},
    {id : 2, label : 'Jewelry', value : 'Jewelry'},
    {id : 3, label : 'Men', value : 'Men'},
    {id : 4, label : 'Home', value : 'Home'},
    {id : 5, label : 'Kitchen', value : 'Kitchen'},
    {id : 6, label : 'MobileAccs', value : 'Mobile Accs'},
    {id : 7, label : 'Bags', value : 'Bags'},
    {id : 8, label : 'Beauty', value : 'Beauty'},
    {id : 9, label : 'Baby', value : 'Baby'},
    {id : 10, label : 'Toys', value : 'Toys'},
    
]

export default productCategory