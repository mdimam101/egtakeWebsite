const productSize = [
    {id : 1, label : 'S', value : 'S'},
    {id : 2, label : 'M', value : 'M'},
    {id : 3, label : 'L', value : 'L'},
    {id : 4, label : 'XL', value : 'XL'},
    {id : 5, label : 'XXL', value : 'XXL'},
]

export default productSize 