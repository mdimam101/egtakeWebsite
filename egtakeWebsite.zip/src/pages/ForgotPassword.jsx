import React from 'react'

const ForgotPassword = () => {
  return (
    <div>
      Forgot Password ?
    </div>
  )
}

export default ForgotPassword
