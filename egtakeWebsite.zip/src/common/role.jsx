const ROLE = {
    ADMIN: 'ADMIN',
    GENERAL: 'GENERAL'
}