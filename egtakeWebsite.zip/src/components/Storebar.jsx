import { IoStorefrontOutline } from "react-icons/io5";
const Storebar = () => {

    return (
        <>
        <IoStorefrontOutline/>
        </>
    )
}
export default Storebar