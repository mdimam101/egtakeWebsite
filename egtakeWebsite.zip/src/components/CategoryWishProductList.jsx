import React from 'react'

const CategoryWishProductList = () => {
  return (
    <div>
      CategoryWishProductList
    </div>
  )
}

export default CategoryWishProductList
