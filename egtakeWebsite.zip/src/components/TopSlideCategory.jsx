import React from 'react';
import '../styles/TopSlideCategoryStyles.css'

const TopSlideCategory = () => {
  return (
    <div className='TopSlideCategory'>
      All, man , home, kitchen, boys, etc
    </div>
  )
}

export default TopSlideCategory
